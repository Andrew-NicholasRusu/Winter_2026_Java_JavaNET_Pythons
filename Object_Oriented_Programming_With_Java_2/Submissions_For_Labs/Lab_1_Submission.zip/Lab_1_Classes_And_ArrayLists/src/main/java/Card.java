public class Card {
    private String suit;
    private String rank;
    private int value;

    // Constructors
    public Card() {
        this.suit = "";
        this.rank = "";
        this.value = 0;
    }

    public Card(String suit, String rank, int value) {
        this.suit = suit;
        this.rank = rank;
        this.value = value;
    }

    public Card(String suit, String rank) {
        this.suit = suit;
        this.rank = rank;
        if (this.rank.equals("Ace"))
            this.value = 1;
        else if (this.rank.equals("Jack"))
            this.value = 1;
        else if (this.rank.equals("Queen"))
            this.value = 11;
        else if (this.rank.equals("King"))
            this.value = 13;
        else this.value = Integer.parseInt(this.rank);
    }

    // Accessor methods
    public String getSuit() {
        return this.suit;
    }

    public String getRank() {
        return this.rank;
    }

    public int getValue() {
        return this.value;
    }

    // Mutator Methods
    public void setSuit(String suit) {
        this.suit = suit;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public void setValue(int value) {
        this.value = value;
    }

    // toString() Method
    @Override
    public String toString() {
        String result = "";
        result = this.rank + " of " + this.suit + " with value " + this.value;
        return result;
    }

    // equals() Method
    public boolean equals(Card secondObject) {
        // Compare this object with the second object.
        boolean result = true;
        if (this.suit.equals(secondObject.suit) && this.rank.equals(secondObject.rank) && this.value == secondObject.value)
            result = true;
        else
            result = false;

        return result;
    }
}
public class PhoneBookEntry {
    private String name;
    private String phonenumber;

    // Constructor
    public PhoneBookEntry(String name, String phonenumber) {
        this.name = name;
        this.phonenumber = phonenumber;
    }

    // Accessors
    public String getName(){
        return this.name;
    }

    public String getPhonenumber() {
        return  this.phonenumber;
    }

    // Mutators
    public void setName(String name) {
        this.name = name;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

}

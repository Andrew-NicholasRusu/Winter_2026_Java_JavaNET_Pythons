import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello and welcome!\n");

        /// //////////////////////////////
        /// Problem 1
        /// /////////////////////////////
        Card c1 = new Card("hearts", "Ace");
        Card c2 = new Card("Diamonds", "King");
        Card c3 = new Card("Clubs", "7");
        Card c4 = new Card("Diamonds", "2");

        ArrayList<Card> deck = new ArrayList<Card>();
        deck.add(c1);
        deck.add(c2);
        deck.add(c3);
        deck.add(c4);

        displayDeck(deck);
        // Removes the third Card object from the ArrayList. Display Deck.
        deck.remove(2);
        System.out.println("");
        System.out.println("Deck after removing index 2 (Clubs): ");
        displayDeck(deck);
        // Insert a new card (spades, 10) between (hearts, ace) (Diamonds, King). Display Deck.
        c1 = new Card("Spades", "10");
        deck.add(1, c1);
        System.out.println("");
        System.out.println("Deck after adding (spades, 10)");
        displayDeck(deck);

        /// /////////////////////////////////
        /// Problem 2
        /// ////////////////////////////////
        ArrayList<PhoneBookEntry> phonebooklist = new ArrayList<PhoneBookEntry>();
        phonebooklist.add(new PhoneBookEntry("Thomas", "543-619-7604"));
        phonebooklist.add(new PhoneBookEntry("Micheal", "514-618-3404"));
        phonebooklist.add(new PhoneBookEntry("Andrew", "438-370-7009"));
        phonebooklist.add(new PhoneBookEntry("Silvia", "314-9067-2007"));
        phonebooklist.add(new PhoneBookEntry("Rose", "764-445-7205"));

        System.out.println("--- Phone Book Entries ---");
        for (PhoneBookEntry entry : phonebooklist)
            System.out.println("Name: " + entry.getName() + " | Phone Number: "+entry.getPhonenumber());


        ////////////////////////////////////
        /// Problem 3
        ////////////////////////////////////
        // Declare an empty (do not define a size) ArrayList of Strings, call it cityList
        ArrayList<String> cityList = new ArrayList<String>();
        System.out.println("");
        System.out.println("List of cities:");
        cityList.add("London");
        cityList.add("Denver");
        cityList.add("Paris");
        cityList.add("Miami");
        cityList.add("Seoul");
        cityList.add("Tokyo");
        displayCities(cityList);

        // Print in the standard output the size of the list
        System.out.println();
        System.out.println("List size? " + cityList.size());
        // Use a method to check if Miami is in the list
        if (cityList.contains("Miami")) {
            System.out.println("Miami is on the list!");
        } else {
            System.out.println("Miami is not on the list!");
        }

        // You could also do this to Find Miami
        // System.out.println("List size? " + cityList.size());
        // This is because .contains is a boolean, meaning it determines true or false automatically.
        // System.out.println("Is Miami in the list? "+ cityList.contains("Miami"));

        System.out.println("The location of Denver in the list? " + (cityList.indexOf("Denver") + 1));
        System.out.println("Is the list empty? " + cityList.isEmpty());
        System.out.println("");

        // Insert the city Xian at index 2
        cityList.add(2, "Xian");
        // Remove Miami from the list, do not use the index to remove.
        cityList.remove("Miami"); // Takes the object instead of Index
        // Remove a city at index 1.
        cityList.remove(1);
        System.out.println("List of cities after adding Xian, removing Miami, and removing the city at index 1 (Denver):");
        displayCities(cityList);

        System.out.println("");
        System.out.println("List size? " + cityList.size());
        System.out.println("Is Miami in the list? "+ cityList.contains("Miami"));
        System.out.println("The location of Denver in the list? " + (cityList.indexOf("Denver") + 1));
        System.out.println("Is the list empty? " + cityList.isEmpty());
    }

    public static void displayDeck(ArrayList<Card> deck) {
        for (int i = 0; i < deck.size(); i++) {
            Card c = deck.get(i);
            System.out.println(i + 1 + ": " + c);
        }

    // Another way to do it is using the enhanced for loop
    //        for (Card card : Deck) {
    //            System.out.println(card);
    //        }
    }

    public static void displayCities(ArrayList<String> city) {
        for (int i = 0; i < city.size(); i++) {
            String t = city.get(i);
            System.out.println(i + 1 + ": " + t);
        }

    }
}









